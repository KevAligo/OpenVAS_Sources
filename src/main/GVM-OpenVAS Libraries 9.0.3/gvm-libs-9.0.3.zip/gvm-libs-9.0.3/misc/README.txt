This is the library "libopenvas_misc", formerly known as "libopenvas".

As decided in Change Request #38 (http://openvas.org/openvas-cr-38.html), all
this old stuff which is not being re-implemented or obsoleted over time stays
here.

Eventually this library should be empty one day and then be removed.

New, clean code should go into the openvas-libraries/base directory (or any
other directory as described in the Change Request).
