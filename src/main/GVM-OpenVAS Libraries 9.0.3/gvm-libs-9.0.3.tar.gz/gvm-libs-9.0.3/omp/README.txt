This is the library "libopenvas_omp".

It provides a simple XML interface: a reader and some basic tree manipulation.

Any source code of this libraries fulfills the following requirements:

* involves no other dependencies than glib >= 2.12
* licensed under GNU GPLv2 or any later version
* fully documented according to the coding guidelines in order to allow a
  complete automatically generated API documentation.
