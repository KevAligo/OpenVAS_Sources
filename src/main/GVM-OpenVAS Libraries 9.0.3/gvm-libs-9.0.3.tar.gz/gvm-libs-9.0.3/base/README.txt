This is the library "libopenvas_base".

It provides basics for various OpenVAS modules.

Any source code of this library fulfills the
following requirements:

* involves no other dependencies than mandatory
  libraries (glib, gpgme)
* licensed under GNU GPLv2 or any later version
* fully documented according to the coding guidelines
  in order to allow a complete automatically generated
  API documentation.
