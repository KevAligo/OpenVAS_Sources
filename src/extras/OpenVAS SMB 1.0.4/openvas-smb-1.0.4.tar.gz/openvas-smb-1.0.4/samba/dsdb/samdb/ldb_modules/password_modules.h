/* We store these passwords under this base DN: */

#define LOCAL_BASE "cn=Passwords"
