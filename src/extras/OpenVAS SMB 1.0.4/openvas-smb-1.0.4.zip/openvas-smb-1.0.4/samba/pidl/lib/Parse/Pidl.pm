###################################################
# package to parse IDL files and generate code for
# rpc functions in Samba
# Copyright tridge@samba.org 2000-2003
# Copyright jelmer@samba.org 2005
# released under the GNU GPL

package Parse::Pidl;

use strict;

use vars qw ( $VERSION );

$VERSION = '0.02';

1;
